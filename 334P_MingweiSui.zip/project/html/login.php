<?php // login.php
$hn = 'localhost'; //hostname
$db = 'suim_pbl'; //database
$un = 'suim_pbl'; //username
$pw = 'mypassword'; //password
?>